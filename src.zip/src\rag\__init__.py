"""
RAG module - FAISS retrieval with sentence-transformers.
"""

from .retriever import retrieve

__all__ = ["retrieve"]
