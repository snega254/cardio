"""
src/ecg
Member 1's module: PTB-XL ECG signal classification.

Public entry point for the rest of the team is interface.predict().
"""
